import javax.swing.JFrame;

import IHM.MainFrame;

public class Test{
    public static void main(String[] args){
        JFrame f = new MainFrame();
        f.setVisible(true);
        

    }
}